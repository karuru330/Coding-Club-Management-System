#include<stdio.h>
int main(){
	//Write your code here
	return 0;
}