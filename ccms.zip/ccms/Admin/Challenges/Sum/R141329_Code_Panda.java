import java.util.*;
public class R141329_Code_Panda
{
	public static void main(String args[])
	{
               int a,b;
               Scanner scan = new Scanner(System.in);
               a=scan.nextInt();
               b=scan.nextInt();
	       System.out.println(a+b);
	}
}