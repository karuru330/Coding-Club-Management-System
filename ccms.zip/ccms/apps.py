from django.apps import AppConfig


class CcmsConfig(AppConfig):
    name = 'ccms'
